Description:
TrackPlug is a simple plugin allowing you to take track of the time you spend in your games.

How to install:
- Install the VPK file
- Place the .suprx file in ux0:/tai
- Place the .skprx file in ux0:/tai
- Install the skprx in your config.txt under *KERNEL.
- Install the suprx in your config.txt under *ALL or under whatever game you want to track.

How to use:
The plugin will automatically take playtime info. You can use the TrackPlug vpk application to see current playtime status for every game you started at least once.

Controls:
Triangle - Delete current playtime status for selected game
Up / Down - Change selected game status
L / R - Change game ordering type
Select - Change colors for the background

Why the VPK is marked as unsafe:
That's because the application requires ur0:/appmeta and ux0:/app access to grab title and icon for tracked games.

Credits:
Red7s and Slade for testing the homebrew.