Introduction:
--------------
VITA2PC is a tool allowing you to stream video+audio from your PSVITA to your PC via WiFi connection.

How to:
--------------
- Install the .suprx plugin and put it under *TITLEID where TITLEID is the game where you want to use it (NOTE: Do NOT use *ALL cause it will cause a freeze on enso bootup due to incompatibility with Livearea (*main).)
- Launch the game you want to stream and press SELECT + L to trigger VITA2PC config menu.
- Select your favourite settings and select "Start Screen Streaming"
- On PC side launch the PC client and insert the IP shown on PSVITA when requested.
- Select your favourite audio driver.

Audio Streaming:
--------------
As of now, audio streaming is still an experimental feature that may cause slowdowns, stutterings and/or mute audio issues. Be careful of these known issues if you're using it.

SDL Mixer vs OpenAL audio driver:
--------------
On v.0.2 OpenAL audio driver got added. When to use one and when the other?
OpenAL audio driver is more unstable if compared to SDL Mixer (can cause game to crash) but in games using more than one audio channel it will have a lot better audio output compared to SDL Mixer (eg: DigimonStory: CyberSleuth).
On the other side, when a game uses only a single audio channel, SDL Mixer is recommended (eg. Sword Art Online: Lost Song).

Video filters and PC Window size:
--------------
On v.0.2 an icon on system tray got added for VITA2PC.
If you click on such icon, you can switch current video mode to:

- Original Resolution (No Filter)
- Original Resolution (Bilinear Filter)
- Vita Resolution (No Filter)
- Vita Resolution (Bilinear Filter)

Changelog:
--------------
- Added compatibility patch for Uncharted: Golden Abyss (EUR)
- Added compatibility patch for Muramasa Rebirth (EUR)
- Added compatibility patch for Ratchet and Clank 2 (EUR)
- Added compatibility patch for Ratchet and Clank 3 (EUR)
- Added LPDDR2 hardware encoder support (a lot more games will now support hardware accelerated encoding).
- Added support on PC side for window resolution switching between Original and Vita resolution.
- Added support on PC side for Bilinear filtering.
- Fixed a bug in SDL Mixer audio driver causing audio stalling on PC side in certain circumstances.
- Added an icon for the PC client.
- Added a new audio driver based on OpenAL on PC side.

Credits:
--------------
- frangarcj for helping me figure out how to properly hook power save mode enabling by games.
- xerpi for the huge work on reverse engineering Vita modules allowing to get more features (like LPDDR2 hw encoder) on VITA2PC.
- MrMojoR70062297 for the awesome icon used on PC client.
- All my Patroners for their awesome support:
* Styde Pregny
* BillyMcLaughlin II
* XandridFire
* Samuel Batista
* Jaden Emrich
* Justin
* Edd
* Setiyagung
* Ramerson Wesley Ara�jo
* temp_anon
* 2Mourty
* gnmmarechal
* Bryan Hanbury
* Gelson Silva